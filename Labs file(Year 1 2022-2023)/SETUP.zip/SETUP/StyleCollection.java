import java.util.HashMap;

public class StyleCollection {

  HashMap<String, Style> style;

  public StyleCollection() {

    style = new HashMap<String, Style>();
  }
  
  public void addStyle(Style s) {
    style.put(s.getName(), s);
  }
  
  public void setDefaultStyle(Style s) {
    style.put("default", s);
  }
 
  public Style getStyle(String s) {
    return style.get(s);
    }
    
    public Style getDefaultStyle(){
    return style.get("default");
  }
}
