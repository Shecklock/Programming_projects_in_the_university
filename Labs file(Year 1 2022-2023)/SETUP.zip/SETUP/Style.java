
public class Style {
  
  int fillColor;
  int strokeColor;
  int bgColor;
  int textSize;
  String name;


  public Style(int C, int Sc, int bg, int tS, String n) {
    fillColor = C;
    strokeColor = Sc;
    bgColor = bg;
    textSize = tS;
    name = n;
  }

  public int getFillColor() {
    return fillColor;
  }

  public int getStrokeColor() {
    return strokeColor;
  }

  public int getBgColor() {
    return bgColor;
  }

  public int getTextSize() {
    return textSize;
  }

  public String getName() {
    return name;
  }
}
