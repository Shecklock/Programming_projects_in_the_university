package uk.ac.aston.oop.uml.media;

import java.util.ArrayList;

public class Database {
	
	ArrayList<Item> Database = new ArrayList<Item>();
	
public Database() {}
    
public void addItem(Item i) {
	Database.add(i);
}

public void print() {
	for (int i = 0; i < Database.size(); i++) {
		System.out.println(Database.get(i));
	}
}

public static void main(String[] args) {
	Database D = new Database();
	Video v = new Video("vic", "rock", 100);
	CD dc = new CD("Damn", "rock", 100, 20);
	D.addItem(v);
	D.addItem(dc);
	D.print();
}
}
