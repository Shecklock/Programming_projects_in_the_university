package uk.ac.aston.oop.uml.media;

public abstract class Item {
	
	protected int playMinutes;
	protected String title;
	protected String comment="";
	private boolean owned=false;
	
	public Item(String title, int playMinutes) {
		this.playMinutes = playMinutes;
		this.title = title;
	}

	public String getComment() {
		return this.comment;
	}
	
	public void setComment(String c){
	    this.comment =  c;
	}
	
	public boolean isOwned() {
return owned;
	}
	
	public void setOwned(boolean o) {
		this.owned = o;
	}
	
	public int getPlayMinutes() {
		return this.playMinutes;
	}
	
	public String toString() {
		if (!isOwned()) {
			return title + ":" + playMinutes + "-" + comment;
		}else {
			return "*" + title + ":" + playMinutes + "-" + comment;
		}
}
}
