package uk.ac.aston.oop.uml.media;

public class CD extends Item{
	
	public final String artist;
	public final int nTracks;

	public CD(String title, String artist, int nTracks, int playMinutes) {
		super(title,playMinutes);
		this.artist=artist;
		this.nTracks = nTracks;
	}
	
	public String getArtist() {
		return this.artist;
	}
	
	public int getNumberOfTracks() {
		return this.nTracks;
	}
	
	@Override
	public int getPlayMinutes() {
		return super.playMinutes;
	}
	
	@Override
	public String toString() {
			return "Artist:" + this.artist + "Number of tracks:" + nTracks + super.toString();
		}
	
}
