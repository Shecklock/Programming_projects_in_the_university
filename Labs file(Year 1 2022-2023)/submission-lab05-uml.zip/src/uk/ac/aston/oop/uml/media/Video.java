package uk.ac.aston.oop.uml.media;

public class Video extends Item{
	
	protected String Director;
	
	public Video(String title, String Director, int playMinutes) {
		super(title, playMinutes);
		this.Director = Director;
		this.title = title;
		this.playMinutes = playMinutes;
	}
	

	public String getDirector() {
		return this.Director;
	}
	
	@Override
	public String toString(){
			return "Director:" + Director + super.toString();
	}
}
