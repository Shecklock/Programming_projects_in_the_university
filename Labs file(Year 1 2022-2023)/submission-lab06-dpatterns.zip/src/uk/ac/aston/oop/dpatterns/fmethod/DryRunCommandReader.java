package uk.ac.aston.oop.dpatterns.fmethod;

public class DryRunCommandReader extends AbstractCommandReader {
    @Override
    protected Runnable createMovementCommand(int dx, int dy) {
        String message = "Move " + dx + " horizontally and " + dy + " vertically";
        return (Runnable) new DryRunCommand(message);
    }
}

