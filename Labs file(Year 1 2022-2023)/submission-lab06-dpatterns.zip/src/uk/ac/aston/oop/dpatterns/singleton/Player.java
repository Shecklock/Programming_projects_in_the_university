package uk.ac.aston.oop.dpatterns.singleton;

public class Player {
	
	private int dieFaces;

	public Player(int dieFaceCount) {
		// TODO Auto-generated constructor stub
		this.dieFaces = dieFaceCount;
	}

	public int roll() {
		// TODO Auto-generated method stub
		DiceRoller DR = DiceRoller.getInstance();
		int result = DR.roll(6);
		return result;
	}

	public int getDieFaces() {
		// TODO Auto-generated method stub
		return dieFaces;
	}

}
