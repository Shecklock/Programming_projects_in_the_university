package uk.ac.aston.oop.dpatterns.singleton;

import java.util.Random;

public class DiceRoller {
	
	private static DiceRoller instance = null;
	private static Long seed;
	private final Random random;
	
	private DiceRoller() {
		if(seed != null) {
			random = new Random(seed);
		} else {
		random = new Random();
	}
	}
	
	public Random random() {
		return random;
	}
	
	public static DiceRoller getInstance() {
		if(instance == null) {
			instance = new DiceRoller();
		}
		return instance;
		}
	
	public int roll(int faces) {
	    return random.nextInt(faces) + 1;
	}
	
	public static void setSeed(long seed) {
	    if (instance == null) {
	        instance = new DiceRoller(); 
	        instance.random().setSeed(seed);
	        } else {
	        System.err.println("Seed already set.");
	    }
	}

}
