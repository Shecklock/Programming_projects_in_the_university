package uk.ac.aston.oop.javafx.assessed;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import uk.ac.aston.oop.javafx.assessed.model.Database;
import uk.ac.aston.oop.javafx.assessed.model.Video;

public class CreateVideoController {

    @FXML
    private TextField titleField;
    @FXML
    private TextField directorField;
    @FXML
    private Slider playingTime;
    @FXML
    private CheckBox Owned;
    @FXML
    private TextArea commentArea;

    private Database database;
    
    private boolean isCreate = false;
    
    public CreateVideoController(Database database) {
    	this.database = database;
    } 
    
    public boolean isCreate() {
    	return isCreate;
    }

    @FXML
    private void CreatePressed(ActionEvent event) {
    	
        String title = titleField.getText();
        String director = directorField.getText();
        int playingTime = (int) this.playingTime.getValue();
        boolean owned = Owned.isSelected();
        String comment = commentArea.getText();

        Video video = new Video(title, director, playingTime);
        video.setComment(comment);
        video.setOwn(owned);
        isCreate = true;
        database.addItem(video);

        closeWindow(event);
        
    }

    @FXML
    private void CancelPressed(ActionEvent event) {
        closeWindow(event);
    }

    private void closeWindow(ActionEvent event) {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }
}
