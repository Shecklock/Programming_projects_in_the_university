package uk.ac.aston.oop.jcf.todo;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * To-do list, implemented through a JCF List.
 */
public class ToDoList implements Iterable<ToDoItem> {

	protected final List<ToDoItem> items = new ArrayList<>();

	@Override
	public Iterator<ToDoItem> iterator() {
		return items.iterator();
	}

	/**
	 * Returns <code>true</code> if the list is empty, <code>false</code> otherwise.
	 * 
	 * @return true if the list is empty, false if not.
	 */
	public boolean isEmpty() {
		return items.isEmpty();
	}

	/**
	 * Adds an item at the end of the list.
	 *
	 * @param toDoItem Item to be added.
	 */
	public void add(ToDoItem toDoItem) {
		items.add(toDoItem);
	}

	/**
	 * Returns the number of items of the list.
	 *
	 * @return Number of items in the list.
	 */
	public int size() {
		return items.size();
	}

	/**
	 * Marks the <code>i</code>-th item in the list as done.
	 *
	 * @param i Position of the item, starting at 0.
	 * @throws IndexOutOfBoundsException if the specified index is out of range.
 */
	public void markDone(int i) throws IndexOutOfBoundsException {
		// TODO needs to be implemented
		ToDoItem item = items.get(i);
		item.setDone(true);
	}

	/**
	 * Removes the <code>i</code>-th item from the list.
	 *
	 * @param i Position of the item, starting at 0.
	 */
	public void remove(int i) {
		items.remove(i);
	}

	/**
	 * Removes all entries whose description contains the specified <code>substring</code>.
	 * 
	 * @param substring Search string.
	 */
	public void removeAllContaining(String substring) {
		// TODO needs to be implemented
		Iterator<ToDoItem> iter = items.iterator();
	    while (iter.hasNext()) {
	        ToDoItem item = iter.next();
	        if (item.getDescription().contains(substring)) {
	            iter.remove();
	        }
	    }
	}

	/**
	 * Remove all items marked as done. 
	 */
	public void removeAllDone() {
		// TODO needs to be implemented
		Iterator<ToDoItem> iter = items.iterator();
	    while (iter.hasNext()) {
	        ToDoItem item = iter.next();
	        if (item.isDone()) {
	            iter.remove();
	        }
	    }
	}

	/**
	 * Moves the <code>i</code>-th item to the first position of the list.
	 *
	 * @param i Position of the item, starting at 0.
	 * @throws IndexOutOfBoundsException if the specified index is out of range.
	 */
	public void moveToTop(int i) throws IndexOutOfBoundsException {
		// TODO needs to be implemented
		if (i > 0) {
	        ToDoItem item = items.remove(i);
	        items.add(0, item);
	    }
	}

	/**
	 * Shuffles the list by visiting each position and swapping the element
	 * at that position with the element at another random position.
	 */
	public void shuffle(Random rnd) {
		// TODO needs to be implemented
		int size = items.size();
	    for (int i = 0; i < size; i++) {
	        ToDoItem item = items.get(i);
	        int otherPosition = rnd.nextInt(size);
	        ToDoItem otherItem = items.get(otherPosition);
	        items.set(i, otherItem);
	        items.set(otherPosition, item);
	    }
	}

}
