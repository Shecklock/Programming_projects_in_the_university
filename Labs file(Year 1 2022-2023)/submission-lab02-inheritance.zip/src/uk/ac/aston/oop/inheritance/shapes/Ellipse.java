package uk.ac.aston.oop.inheritance.shapes;

import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * Ellipse, specified as upper left corner X + upper left corner Y + Width + height. 
 */

public class Ellipse extends Shape{
	
/**
 *Ellipse, specified as upper left corner X + upper left corner Y + Width + height. 
 *@param ulX X coordinate of the upper left corner.
 *@param ulY Y coordinate of the upper left corner.
 *@param width Width of the ellipse.
 *@param height height of the ellipse. 
 */

	public Ellipse(double ulX, double ulY, double width, double height) {
		super(ulX, ulY, width, height);
	}
	
	/**
	 * @return drawing of the shape;
	 */

	@Override
	public void draw(GraphicsContextWrapper gc) {
		gc.oval(getX(), getY(), getWidth(), getHeight());
	}
	
}
