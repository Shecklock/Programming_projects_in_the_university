package uk.ac.aston.oop.inheritance.shapes;
import javafx.scene.paint.Color;
import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * Filled, rectangle with color filled, specified as filled color + upper left corner X + upper left corner Y + Width + height. 
 */

public class FilledRectangle extends Rectangle {

/** @param uplcX X coordinate of the upper left corner.
 * @param uplcY Y coordinate of the upper left corner.
 * @param Color color of the filling the rectangle.
 */
	
	private Color filled;
	
	public FilledRectangle(Color color, double ulcX, double ulcY, double width, double height) {
		super(ulcX,ulcY,width,height);
		this.filled = color;
	}
	
	/**
	 * @return color of the filling;
	 */
	
	public Color getFilled() {
		return this.filled;
	}
	
	/**
	 * @return drawing of the shape;
	 */
	
	@Override
	public void draw(GraphicsContextWrapper gc) {
		super.draw(gc);
		gc.fill(getFilled());
		gc.fillRect(getX(), getY(), getWidth(), getHeight());
	}
}
