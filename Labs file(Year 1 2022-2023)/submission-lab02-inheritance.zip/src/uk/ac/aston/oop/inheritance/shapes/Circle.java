package uk.ac.aston.oop.inheritance.shapes;

import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * Circle, specified as center + radius.  
 */

public class Circle extends Ellipse{
/**
	* Creates a new Circle.
	 *
	 * @param centerX X coordinate of the center.
	 * @param centerY Y coordinate of the center.
	 * @param radius radius of the circle. 
	 */
	public Circle(double centerX, double centerY, double radius) {

		super(centerX - radius, centerY - radius, radius * 2, radius * 2);
	}

	/**
	 * Returns the Radius of the circle.
	 *
	 * @return Radius of the circle.
	 */
	
	public double getRadius() { return (getWidth()/2);}
	
}
