/**
 * Main package of the inheritance lab program.
 *
 * @Ho
 * @version 1.0
 */

package uk.ac.aston.oop.inheritance;
