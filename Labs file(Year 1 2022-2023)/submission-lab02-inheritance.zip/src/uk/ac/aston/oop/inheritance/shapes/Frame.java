package uk.ac.aston.oop.inheritance.shapes;

import javafx.scene.paint.Color;
import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * Frame, rectangle with frame, 
 * specified as upper left corner X + upper left corner Y + Width + height. 
*/

public class Frame extends Shape{
	/**
	 * Frame, creating rectangle with frame thickness, 
	 * specified as upper left corner X + upper left corner Y + Width + height. 
	 *
	 * @param uplcX X coordinate of the upper left corner.
	 * @param uplcY Y coordinate of the upper left corner.
	 * @param FRAME_THICKNESS thickness of the frame of the rectangle.
	 */
	
	protected Rectangle outerRectangle;
	protected Rectangle innerRectangle;
	private static final int FRAME_THICKNESS = 10;
	
	public Frame(double ulcX, double ulcY, double width, double height) {
		
		super(ulcX,ulcY,width,height);
		outerRectangle = new Rectangle(ulcX,ulcY,width,height);
		innerRectangle = new Rectangle(ulcX + FRAME_THICKNESS , ulcY + FRAME_THICKNESS, width - FRAME_THICKNESS * 2, height - FRAME_THICKNESS * 2);
		}
	
	/**
	 * @return drawing of the both rectangle.
	 */
	
	@Override
	public void draw(GraphicsContextWrapper gc) {
		outerRectangle.draw(gc);
		innerRectangle.draw(gc);
		}
	}
	
