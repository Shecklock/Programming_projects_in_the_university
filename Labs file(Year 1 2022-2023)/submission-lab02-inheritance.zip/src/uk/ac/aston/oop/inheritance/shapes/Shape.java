package uk.ac.aston.oop.inheritance.shapes;

import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * Creates a new instance for all the shapes.
 */

public class Shape {
	
	private double upleftcornX, upleftcornY;
	private double width, height;

/**
 * Create new instance.
 * 
 * @param uplcX X coordinate of the upper left corner.
 * @param uplcY Y coordinate of the upper left corner.
 * @param w Width of the shape.
 * @param h Height of the shape.
 */

	public Shape(double uplcX, double uplcY, double w, double h) {
		
		this.upleftcornX = uplcX;
		this.upleftcornY = uplcY;
		this.width = w;
		this.height = h;
	}
	
	/**
	 * Returns the X coordinate of the upper left corner.
	 *
	 * @return X coordinate of upper left corner.
	 */
	
	public double getX() { return upleftcornX; }
	
	/**
	 * Returns the Y coordinate of the upper left corner.
	 *
	 * @return Y coordinate of upper left corner.
	 */
	
	public double getY() { return upleftcornY; }
	
	/**
	 * Returns the width of the shape.
	 *
	 * @return the width of the shape.
	 */
	
	public double getWidth()  { return width; }
	
	/**
	 * Returns the height of the shape.
	 *
	 * @return the height of the shape.
	 */
	
	public double getHeight() { return height; }
	
	/**
	 * 
	 * @param gc telling the programmer this code is working
	 */
	
	public void draw(GraphicsContextWrapper gc) {
		System.out.println("yeet");
	}
}
