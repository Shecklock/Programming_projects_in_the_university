public class Addmain {
	public Addmain() {}
	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("please provide TWO interger parameters");
		}
		else if (args.length == 2){
			Adder a = new Adder();
		    int b = a.add(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
			System.out.println("The result of adding "+ args[0] + " and " + args[1] + " is " + b );
		}
	}
}