public class Adder {
	public Adder(){}
    public int add(int num1, int num2) {
    	int a = num1 + num2;
    	return a;
    }
}
