public class ExampleMain {
	public static void main(String[] args) {
		if(args.length > 0) {
		System.out.println("Hi from Java!");
		System.out.print("First argument is: ");
		System.out.println(args[0]);
		System.out.println("There are " + args.length + " argument");
		}
		else if (args.length == 0){
			System.out.println("You didn't provide any argument");
			}
		} 
		
}