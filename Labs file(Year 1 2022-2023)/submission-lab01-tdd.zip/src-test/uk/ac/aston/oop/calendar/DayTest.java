package uk.ac.aston.oop.calendar;

import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * The test class DayTest.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DayTest {
	// TODO - add your tests here!
@Test public void appointmentStartOfDay() {
	Day day = new Day(1);
	Appointment app = new Appointment("meeting", 1);
	
	boolean success = day.makeAppointment(Day.START_OF_DAY, app);
	Appointment fetched = day.getAppointment(Day.START_OF_DAY);
	
	assertTrue(success, "Making an appointment at the start of a new day should work");
	assertSame(app, fetched, "It should be possible to fetch the appointment we just made");
  }

@Test public void appointmentBeforeStartOfDay() {
	Day day = new Day(2);
	Appointment app = new Appointment("meeting", 1);
	
	boolean success = day.makeAppointment(Day.START_OF_DAY-1, app);
	Appointment fetched = day.getAppointment(Day.START_OF_DAY-1);
	
	assertFalse(success, "Making an appointment before the start of a new day should not work");
	assertNull(fetched, "It should be possible to fetch the appointment we just made");
}

@Test public void twoAppsOnSameTime() {
	Day day = new Day(3);
	Appointment appA = new Appointment("meeting", 1);
	Appointment appB = new Appointment("meeting", 1);
	
	boolean successA = day.makeAppointment(Day.START_OF_DAY, appA);
	Appointment fetchedA = day.getAppointment(Day.START_OF_DAY);
	boolean successB = day.makeAppointment(Day.START_OF_DAY, appB);
	Appointment fetchedB = day.getAppointment(Day.START_OF_DAY);

    assertTrue(successA, "Making an appointment before the start of a new day should work");
    assertSame(appA, fetchedA, "It should be possible to fetch the appointment we just made");
    assertFalse(successB, "Making an appointment of the start of a new day should not work");
    assertSame(appA, fetchedB, "It should be possible to fetch the appointment we just made");
}

@Test public void twoHourAppointmentAtStart() {
	Day day = new Day(4);
	Appointment app = new Appointment("meeting", 2);
	
	boolean success = day.makeAppointment(Day.START_OF_DAY+1, app);
	Appointment fetched = day.getAppointment(Day.START_OF_DAY+1);
	Appointment fetched1 = day.getAppointment(Day.START_OF_DAY+2);
	assertTrue(success, "Making an appointment before the start of a new day should work");
	assertSame(app, fetched, "It should be possible to fetch the appointment we just made");
    assertSame(app, fetched1, "It should be possible to fetch the appointment we just made");
}

@Test public void twoHourAppointmentBeyondEnd() {
	Day day = new Day(5);
    Appointment app = new Appointment("meeting", 2);

    boolean success = day.makeAppointment(Day.FINAL_APPOINTMENT_TIME+1, app);
    Appointment fetched = day.getAppointment(Day.FINAL_APPOINTMENT_TIME+1);
    Appointment fetched2 = day.getAppointment(Day.FINAL_APPOINTMENT_TIME+2);

    assertFalse(success, "Making an appointment before the start of a new day should not work");
    assertNull(fetched, "It should be possible to fetch the appointment we just made");
    assertNull(fetched2, "It should be possible to fetch the appointment we just made");	
 }

@Test public void overlappingTwoHoursAppointments() {
	Day day = new Day(6);
	Appointment appA = new Appointment("meeting", 2);
	Appointment appB = new Appointment("meeting", 2);
	
	boolean successA = day.makeAppointment(Day.START_OF_DAY + 1, appA);
	Appointment fetchedA = day.getAppointment(Day.START_OF_DAY + 1);
	Appointment fetchedA1 = day.getAppointment(Day.START_OF_DAY + 2);
	boolean successB = day.makeAppointment(Day.START_OF_DAY + 1, appB);
	Appointment fetchedB = day.getAppointment(Day.START_OF_DAY + 1);
    Appointment fetchedB1 = day.getAppointment(Day.START_OF_DAY + 2);
    
    assertTrue(successA, "Making an appointment before the start of a new day should work");
    assertSame(appA, fetchedA, "It should be possible to fetch the appointment we just made");
    assertFalse(successB, "Making an appointment of the start of a new day should not work");
    assertSame(appA, fetchedB, "It should be possible to fetch the appointment we just made");
    assertTrue(successA, "Making an appointment before the start of a new day should work");
    assertSame(appA, fetchedA1, "It should be possible to fetch the appointment we just made");
    assertFalse(successB, "Making an appointment of the start of a new day should not work");
    assertSame(appA, fetchedB1, "It should be possible to fetch the appointment we just made");
}
}
