package uk.ac.aston.oop.recipes.io.text;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import uk.ac.aston.oop.recipes.io.RecipeFormat;
import uk.ac.aston.oop.recipes.io.exceptions.RecipeLoadingException;
import uk.ac.aston.oop.recipes.io.exceptions.RecipeSavingException;
import uk.ac.aston.oop.recipes.model.Recipe;

public class TextRecipeFormat implements RecipeFormat {

	public static final String RECIPE_HEADER = "OOPRecipe 1.0";
	public static final String SEPARATOR_INSTRUCTIONS = "__INSTRUCTIONS__";

	@Override
	public String getExtension() {
		return "txt";
	}

	@Override
	public String getDescription() {
		return "Raw Text Files (*.txt)";
	}

	@Override
	public Recipe load(File f) throws RecipeLoadingException {
		

		// TODO 1. safely open the file in a try-with-resources
		// TODO 2. catch IOException, wrap it and throw it
		// TODO 3. inside the try block, do the following

		try (FileReader fr = new FileReader(f, StandardCharsets.UTF_8);
				LineNumberReader lnr = new LineNumberReader(fr)) {
			Recipe r = new Recipe();
			lnr.setLineNumber(1);
			checkHeader(lnr, f);

			readRecipeName(lnr, r);
			readIngredients(lnr, r);
			readInstructions(lnr, r);
			return r;

		} catch (IOException e) {
			throw new RecipeLoadingException("cannot load file");
			
		}
		
	}

	private void readInstructions(LineNumberReader lnr, Recipe r) throws IOException {
		// TODO read all the remaining lines and set the instructions
		List lines = new ArrayList();
		String line = lnr.readLine();
		while (line != null) {
			lines.add(line);
			line = lnr.readLine();
		}
		String instructions = String.join(System.lineSeparator(), lines);
		r.instructionsProperty().set(instructions);
	}

	private void readIngredients(LineNumberReader lnr, Recipe r) throws IOException, RecipeLoadingException {
		// TODO read all the lines up to end-of-file or SEPARATOR_INSTRUCTIONS
		List lines = new ArrayList();
		String line = lnr.readLine();
		while (line != null && !line.equals(SEPARATOR_INSTRUCTIONS)) {
			lines.add(line);
			line = lnr.readLine();
		}
		// TODO set the ingredients property of the recipe
		if (!SEPARATOR_INSTRUCTIONS.equals(line)) {
			throw new RecipeLoadingException(
					"The file is missing the instructions seperator. Line:" + lnr.getLineNumber());
		}
		String ingredients = String.join(System.lineSeparator(), lines);
		r.ingredientsProperty().set(ingredients);
	}


	

	private void readRecipeName(LineNumberReader lnr, Recipe r) throws IOException, RecipeLoadingException {
	// TODO read a line
		String line = lnr.readLine();
		if(line == null) {
			throw new RecipeLoadingException("The recipe file ended prematurely before a name could be read. Line:" + lnr.getLineNumber());
		}
		r.nameProperty().set(line.strip());
	}
	private void checkHeader(LineNumberReader lnr, File f) throws IOException, RecipeLoadingException {
		// TODO read a line
		String line = lnr.readLine();
		// TODO if it's not RECIPE_HEADER, throw a recipe loading exception
		if(!RECIPE_HEADER.equals(line)) {
			throw new RecipeLoadingException("the file is not a recipe file (it does not have our header)" + lnr.getLineNumber());
		}
	}

	@Override
	public void save(Recipe r, File f) throws RecipeSavingException {
		
		if (r.ingredientsProperty().get().contains(SEPARATOR_INSTRUCTIONS)) {
			throw new RecipeSavingException("we cannot save files with that bit of text in its ingredients in the custom text format" + r.ingredientsProperty().get());
		}
		try (FileWriter fw = new FileWriter(f, StandardCharsets.UTF_8); PrintWriter pw = new PrintWriter(fw)) {
			pw.println(RECIPE_HEADER);
			pw.println(r.nameProperty().get());
			pw.println(r.ingredientsProperty().get());
			pw.println(SEPARATOR_INSTRUCTIONS);
			pw.println(r.instructionsProperty().get());

		} catch (IOException e) {
			throw new RecipeSavingException("cannot save file");
		}

		

	}

}
