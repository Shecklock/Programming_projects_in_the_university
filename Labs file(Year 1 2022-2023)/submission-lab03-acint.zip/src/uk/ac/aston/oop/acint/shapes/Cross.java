package uk.ac.aston.oop.acint.shapes;

import uk.ac.aston.oop.acint.util.GraphicsContextWrapper;

public class Cross implements Drawable{
	protected static final int SIZE = 20;
	double centreX, centreY;
	
	public Cross(double cX, double cY) {
		this.centreX = cX;
		this.centreY = cY;
	}
	public void draw(GraphicsContextWrapper gc) {
		gc.line(centreX - SIZE/2, centreY - SIZE/2, centreX + SIZE/2, centreY + SIZE/2);
		gc.line(centreX + SIZE/2, centreY - SIZE/2, centreX - SIZE/2, centreY + SIZE/2);
	};
	
	public void move(GraphicsContextWrapper gc, double dx, double dy) {
		this.centreX = this.centreX + dx;
		this.centreY = this.centreY + dy;
		
		if ((this.centreX + SIZE/2) > gc.width()) {
			this.centreX = gc.width() - SIZE/2;
		}
		if ((this.centreY + SIZE/2)> gc.height()) {
			this.centreY = gc.height()- SIZE/2;
		}
	}
	
}
