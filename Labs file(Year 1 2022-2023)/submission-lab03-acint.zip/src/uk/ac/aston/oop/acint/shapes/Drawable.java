package uk.ac.aston.oop.acint.shapes;

import uk.ac.aston.oop.acint.util.GraphicsContextWrapper;

public interface Drawable {
	
	public void move(GraphicsContextWrapper gc, double dx, double dy);

	public abstract void draw(GraphicsContextWrapper gc);
}
