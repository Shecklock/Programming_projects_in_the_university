package uk.ac.aston.oop.rdd.sim;

import java.util.ArrayList;
import java.util.Random;

public class GridCell {

	private final ArrayList<Actor> contents;
	private final int row;
	private final int column;
	private final Grid grid;
	
	public GridCell(Grid grid, int row, int column) {
		this.row = row;
		this.column = column;
		this.grid = grid;
		contents = new ArrayList<Actor>(); 
	}
	
	public Grid getGrid() {
		return grid;
	}
	public ArrayList<Actor> getContents() {
		return contents;
	}
	
	public int getRow() {
		return row;
	}
	
	public int getColumn() {
		return column;
	}
	
	public ArrayList<GridCell> getAdjacent() {
		ArrayList<GridCell> results = new ArrayList<GridCell>();
		
		for (int r = row - 1; r <= row + 1; r++) {
			for (int c = column - 1; c <= column + 1; c++) {

			if (r == row && c == column) {
                //do nada
				}
			else if(r < 0 || c < 0 || r >= grid.getHeight() || c >= grid.getWidth()) 
			{
				// do nada
			}else {
				
				results.add(grid.get(r,c));
		}
	}
	}
		return results;
	}
	
	public ArrayList<GridCell> getFreeAdjacent(){
		
		ArrayList<GridCell> adjacentCells = getAdjacent();
		ArrayList<GridCell> freeAdjacentCells = new ArrayList<GridCell>();
		
		for (GridCell cell : adjacentCells){
			 if (cell.getContents().isEmpty()) {
				 freeAdjacentCells.add(cell);
			 }
		}
		
		return freeAdjacentCells;
	}

	public GridCell getRandomFreeAdjacent(Random rnd) {
		ArrayList<GridCell> freeAdjacent = getFreeAdjacent();
		if (freeAdjacent.isEmpty()) {
			return null;
		} else {
		int randomIndex = rnd.nextInt(freeAdjacent.size());
		return freeAdjacent.get(randomIndex);
	}
	}
}
