package uk.ac.aston.oop.rdd.sim;

public class Grid {
	private final int width;
	private final int height;
	private final GridCell[][] rows;
	
	public Grid(int dh,int dw) {
		
		this.width = dw;
		this.height = dh;
		
        rows = new GridCell[height][];
                
		for (int i = 0; i < rows.length; i ++) {
			rows[i] = new GridCell[width];
			for (int j = 0; j < rows[i].length; j ++) {
				rows[i][j]= new GridCell(this, i, j);
			}
		}
	}
	
	public int getWidth() {
		return this.width;
	}

	public int getHeight() {
		return this.height;
	}
	
	public GridCell get(int rows, int column) {
		return this.rows[rows][column];
	}
}
