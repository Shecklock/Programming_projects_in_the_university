import java.util.ArrayList;
import java.util.Collections;

public class PhoneList {
  private ArrayList<Phone> phones;

  public PhoneList() {
    phones = new ArrayList<Phone>();
  }

  public void addPhone(Phone phone) {
    phones.add(phone);
  }

  public float getSize() {
    return phones.size();
  }

  public void printPhoneList() {
    for (Phone p : phones) {
      System.out.println(p);
    }
  }

  public void sort() {
    Collections.sort(phones);
  }

  public PhoneList getCostOver(int price) {
    PhoneList pl= new PhoneList();

    for (Phone p : phones) {
      if (p.getApprox_price_EUR() > price) {
        pl.addPhone(p);
      }
    }
    return pl;
  }

  public Phone findPhone(String brand, String model) {

    for (Phone p : phones) {
      if (p.getBrand().equals(brand) && p.getModel().equals(model)) {
        return p;
      }
    }
    return null;
  }
}
