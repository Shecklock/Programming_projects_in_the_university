import java.util.HashMap;

public class PhoneMap {
  private HashMap<String, Phone> phones;

  public PhoneMap() {
    phones = new HashMap<String, Phone>();
  }

  public void addPhone(Phone phone) {
    String k = phone.getBrand()+phone.getModel();
    phones.put(k, phone);
  }

  public float getSize() {
    return phones.size();
  }

  public void printPhoneMap() {
    for (String K : phones.keySet()) {
      Phone p = phones.get(K);
       System.out.println(K);
    }
    //System.out.println(K);
  }

  public PhoneMap getCostOver(float Price) {
    PhoneMap pl= new PhoneMap();
    for (Phone p : phones.values()) {
      if (p.getApprox_price_EUR() > Price) {
        pl.addPhone(p);
      }
    }
    return pl;
  }

  public Phone findPhone(String brand, String model) {

    for (Phone p : phones.values()) {
      //Phone pi = phones.get(p);
      if (p.getBrand().equals(brand) && p.getModel().equals(model)) {
        return p;
      }
    }
    return null;
  }
}
