package uk.ac.aston.oop.javafx.prep;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Window;
import uk.ac.aston.oop.javafx.prep.model.Item;

public class RemoveController {
	
	private boolean confirmed = false;
	private Item selectedItem;
	
	@FXML 
	private javafx.scene.control.Label lblItem;

	public RemoveController(Item selectedItem) {
		this.selectedItem = selectedItem;
	}

	@FXML
	public void initialize() {
		 lblItem.setText(selectedItem.toString());
	}
	
	public boolean isConfirmed() {
		return confirmed;
	}
	
	@FXML
	public void confirmPressed() {
		confirmed = true;
		Scene scene = lblItem.getScene();
        if (scene != null) {
            Window window = scene.getWindow();
            if (window instanceof Stage) {
                ((Stage) window).hide();
            }
        }
	}
	
	@FXML
	public void cancelPressed() {
		confirmed = false;
		Scene scene = lblItem.getScene();
		if (scene != null) {
            Window window = scene.getWindow();
            if (window instanceof Stage) {
                ((Stage) window).hide();
                }
            }
		}
	}
